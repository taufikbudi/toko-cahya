<?php require_once('../../Connections/toko_cahya.php'); ?>

<?php 
$id = $_GET['id_bayar'];

$query = "UPDATE bayar SET status = 1 WHERE id_bayar=$id";
$ex = mysql_query($query, $toko_cahya);
header('Refresh:0;url=index.php');